import 'package:chat_app/services/auth/auth_service.dart';
import 'package:chat_app/services/chat/chat_services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class ChatPage extends StatelessWidget {
  final String recieverEmail;
  final String receiverID;

  ChatPage({super.key, required this.recieverEmail, required this.receiverID});

  //text controller
  final TextEditingController _messageController = TextEditingController();

  //chat & auth services
  final ChatServices _chatService = ChatServices();
  final AuthService _authService = AuthService();

  //send message
  void sendMessage() async
  {
    //send message only if there is any textfield
    if(_messageController.text.isNotEmpty)
      {
        await _chatService.sendMessage(receiverID, _messageController.text);

        //clear text controller after sent
        _messageController.clear();
      }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(recieverEmail),
      ),
      body: Column(
        children: [
          Expanded(child: _buildMessageList(),),

          _buildUserInput(),
        ],
      ),
    );
  }
}

Widget _buildMessageList() {
  String senderId = _authService.getCurrentUser()!.uid;
  return StreamBuilder(
      stream: _chatService.getMessages(receiverID, senderId),
      builder: (context, snapshot)
  {
    if(snapshot.hasError)
    //errors
      {
        return const Text("Error");
      }

    if(snapshot.connectionState== ConnectionState.waiting){
      return const Text("Loading..");
    }

    return ListView(
      children: snapshot.data!.docs.map((doc) => _buildMessageItem(doc)).toList(),
    );
  });
}

//
Widget _buildMessageItem(DocumentSnapshot doc)
{
  Map<String, dynamic> data = doc.data() as Map<String, dynamic>;

  //for current user
  bool isCurrentUser = data['senderID'] == _authService.getCurrentUser

  // align message to right if sender is user else left
  var alignment = isCurrentUser? Alignment.centerRight : Alignment.centerLeft;



  return Container(
    alignment: alignment,
        child: Column(
          crossAxisAlignment: isCurrentUser ? CrossAxisAlignment.end: CrossAxisAlignment.start,
          children: [
            Text(data["message"]),
          ],
        ));
}

//message input
Widget _buildUserInput()
{
  return Padding(
    padding: const EdgeInsets.only(bottom: 50.0),
    child: Row(
      children: [
        Expanded(child: MyTextField(
          controller: _messageController,
          hintText: "Type a message",
          obscureText: false,
        )
        ),

        Container(
          decoration: const BoxDecoration(
              color: Colors.green,
            shape: BoxShape.circle
          ),
            child: IconButton(
                onPressed: sendMessage,
                icon: const Icon(Icons.arrow_upward, color: Colors.white,)))
      ],
    ),
  );
}